<footer class="row">
      <div class="col-sm-12 col-md-3 col-lg-3">
        <a href="index.php"><img src="./img/logos-white.png" alt="footer logo"></a>
      </div>
      <div class="col-sm-12 col-md-6 col-lg-6">
        <h4>Footer Title</h4>
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
      </div>
      <div class="col-sm-12 col-md-3 col-lg-3">
        <form action="#" method="post">
          <p><input class="form-control" type="text" placeholder="Full Name" required></p>
          <p><input class="form-control" type="email" placeholder="Your Email" required></p>
          <input class="btn btn-light" type="submit" value="Send">
        </form>
      </div>
    </footer>
  </body>
</html>
